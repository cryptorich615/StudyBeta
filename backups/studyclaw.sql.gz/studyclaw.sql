--
-- PostgreSQL database dump
--

\restrict vgDmAiQIS3WpjKsiYOO2w4sVVDnpDfO298rEhZKvjgYTAZ2cKBbWEujd77ZNySo

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: asset_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.asset_type AS ENUM (
    'typed_note',
    'image_note',
    'audio_note',
    'uploaded_pdf',
    'summary',
    'flashcard_set',
    'quiz',
    'mock_test'
);


ALTER TYPE public.asset_type OWNER TO postgres;

--
-- Name: message_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.message_role AS ENUM (
    'system',
    'user',
    'assistant',
    'tool'
);


ALTER TYPE public.message_role OWNER TO postgres;

--
-- Name: quiz_mode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.quiz_mode AS ENUM (
    'practice',
    'timed',
    'exam'
);


ALTER TYPE public.quiz_mode OWNER TO postgres;

--
-- Name: reminder_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.reminder_status AS ENUM (
    'scheduled',
    'sent',
    'cancelled'
);


ALTER TYPE public.reminder_status OWNER TO postgres;

--
-- Name: reminder_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.reminder_type AS ENUM (
    'exam',
    'assignment',
    'study_session',
    'meeting',
    'custom'
);


ALTER TYPE public.reminder_type OWNER TO postgres;

--
-- Name: school_level; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.school_level AS ENUM (
    'middle_school',
    'high_school',
    'college',
    'graduate',
    'other'
);


ALTER TYPE public.school_level OWNER TO postgres;

--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ begin new.updated_at = now(); return new; end; $$;


ALTER FUNCTION public.set_updated_at() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_agents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_user_id uuid,
    openclaw_agent_id text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_agents OWNER TO postgres;

--
-- Name: agent_actions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_actions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    action_type character varying(50) NOT NULL,
    summary text NOT NULL,
    payload jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agent_actions OWNER TO postgres;

--
-- Name: agent_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    openclaw_agent_id text NOT NULL,
    model_key text DEFAULT 'gpt-5'::text NOT NULL,
    persona_name text DEFAULT 'StudyClaw'::text NOT NULL,
    tone text DEFAULT 'supportive'::text NOT NULL,
    verbosity text DEFAULT 'concise'::text NOT NULL,
    teaching_style text DEFAULT 'step-by-step'::text NOT NULL,
    reminder_style text DEFAULT 'proactive'::text NOT NULL,
    system_prompt text NOT NULL,
    preset_key text,
    custom_instructions text,
    core_traits_version text DEFAULT 'v1'::text NOT NULL,
    last_reset_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agent_profiles OWNER TO postgres;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    openclaw_agent_id text NOT NULL,
    name character varying(100) DEFAULT 'My Study Agent'::character varying NOT NULL,
    agent_type character varying(20) NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agents_agent_type_check CHECK (((agent_type)::text = ANY ((ARRAY['custom'::character varying, 'quick_start_1'::character varying, 'quick_start_2'::character varying])::text[]))),
    CONSTRAINT agents_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'disabled'::character varying, 'reset_pending'::character varying])::text[])))
);


ALTER TABLE public.agents OWNER TO postgres;

--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    role public.message_role NOT NULL,
    content text NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chat_messages OWNER TO postgres;

--
-- Name: chat_threads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat_threads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    openclaw_session_id text NOT NULL,
    title text,
    last_message_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chat_threads OWNER TO postgres;

--
-- Name: coach_knowledge_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coach_knowledge_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title text NOT NULL,
    detail text NOT NULL,
    source_type text DEFAULT 'note'::text NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.coach_knowledge_items OWNER TO postgres;

--
-- Name: flashcard_sets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flashcard_sets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    subject_id uuid,
    source_asset_id uuid,
    title text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.flashcard_sets OWNER TO postgres;

--
-- Name: flashcards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flashcards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    set_id uuid NOT NULL,
    front text NOT NULL,
    back text NOT NULL,
    difficulty smallint,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.flashcards OWNER TO postgres;

--
-- Name: quiz_questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quiz_questions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    quiz_id uuid NOT NULL,
    question_text text NOT NULL,
    question_type text DEFAULT 'multiple_choice'::text NOT NULL,
    choices_json jsonb,
    answer_json jsonb,
    explanation text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quiz_questions OWNER TO postgres;

--
-- Name: quizzes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quizzes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    subject_id uuid,
    source_asset_id uuid,
    title text NOT NULL,
    mode public.quiz_mode DEFAULT 'practice'::public.quiz_mode NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.quizzes OWNER TO postgres;

--
-- Name: reminders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reminders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type public.reminder_type NOT NULL,
    title text NOT NULL,
    reminder_at timestamp with time zone NOT NULL,
    status public.reminder_status DEFAULT 'scheduled'::public.reminder_status NOT NULL,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reminders OWNER TO postgres;

--
-- Name: student_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student_profiles (
    user_id uuid NOT NULL,
    school_name text,
    school_level public.school_level DEFAULT 'other'::public.school_level NOT NULL,
    grade_year text,
    timezone text DEFAULT 'America/New_York'::text NOT NULL,
    learning_style text,
    onboarding_complete boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    major text
);


ALTER TABLE public.student_profiles OWNER TO postgres;

--
-- Name: study_assets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.study_assets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    subject_id uuid,
    asset_type public.asset_type NOT NULL,
    title text NOT NULL,
    original_text text,
    processed_text text,
    file_url text,
    metadata_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.study_assets OWNER TO postgres;

--
-- Name: subjects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subjects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    teacher_name text,
    color text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.subjects OWNER TO postgres;

--
-- Name: user_google_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_google_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    google_subject text NOT NULL,
    google_email public.citext,
    access_token text NOT NULL,
    refresh_token text,
    scope text NOT NULL,
    token_type text DEFAULT 'Bearer'::text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_google_tokens OWNER TO postgres;

--
-- Name: user_model_credentials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_model_credentials (
    user_id uuid NOT NULL,
    provider_id text NOT NULL,
    api_key text,
    oauth_connected boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_model_credentials OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email public.citext NOT NULL,
    google_id text,
    password_hash text,
    full_name text,
    role text DEFAULT 'student'::text NOT NULL,
    auth_provider text DEFAULT 'email'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: admin_agents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_agents (id, owner_user_id, openclaw_agent_id, config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_actions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_actions (id, agent_id, action_type, summary, payload, created_at) FROM stdin;
a3089625-46d0-40dc-9093-3e5889e45048	d3f4f02e-f84e-4a63-a9db-01b47633da51	chat_error	OpenClaw chat request failed.	{"error": "fetch failed"}	2026-03-21 03:17:37.016418+00
aa9ca24c-fbc3-439d-9707-e2d5b1957276	66bec3a1-1e30-4242-8f78-11861678ac06	chat_reply	Replied in chat thread d1cb29aa-0c05-40c8-ac4a-932831083dbe.	{"threadId": "d1cb29aa-0c05-40c8-ac4a-932831083dbe", "openclawSessionId": "resp_1774065909890"}	2026-03-21 04:05:14.304926+00
373f994d-f771-4149-abb4-877d74d06d2b	66bec3a1-1e30-4242-8f78-11861678ac06	chat_reply	Replied in chat thread d1cb29aa-0c05-40c8-ac4a-932831083dbe.	{"threadId": "d1cb29aa-0c05-40c8-ac4a-932831083dbe", "openclawSessionId": "resp_1774065909890"}	2026-03-21 04:06:04.887958+00
a2d4ddf1-fa2f-4975-ab72-58ff6468e74b	66bec3a1-1e30-4242-8f78-11861678ac06	chat_reply	Replied in chat thread d1cb29aa-0c05-40c8-ac4a-932831083dbe.	{"threadId": "d1cb29aa-0c05-40c8-ac4a-932831083dbe", "openclawSessionId": "resp_1774065909890"}	2026-03-21 04:07:09.336884+00
3874d344-9ae0-4a4f-8877-f8fafc8e243a	e6cd5a52-2026-4b09-9537-4c3aeee75d8f	chat_error	OpenClaw chat request failed.	{"error": "fetch failed"}	2026-03-21 12:59:10.29199+00
840e51c8-fa8d-4fc2-b023-e69a0b85298f	98d9a5fc-823d-4715-a55a-ac1e3c544dc5	chat_reply	Replied in chat thread d5c8eaff-98b0-4dce-9bd4-1ff003074abd.	{"threadId": "d5c8eaff-98b0-4dce-9bd4-1ff003074abd", "openclawSessionId": "resp_1774134234438"}	2026-03-21 23:04:01.217582+00
9f5fa8e2-592d-40a6-bda2-fd2e197f383d	98d9a5fc-823d-4715-a55a-ac1e3c544dc5	chat_reply	Replied in chat thread d5c8eaff-98b0-4dce-9bd4-1ff003074abd.	{"threadId": "d5c8eaff-98b0-4dce-9bd4-1ff003074abd", "openclawSessionId": "resp_1774134234438"}	2026-03-21 23:04:31.067462+00
7415f0e2-6c38-4880-b629-404b205b92d4	42657eda-4204-4d9a-bb62-175f3e54318d	chat_reply	Replied in chat thread ace86c7b-f5b6-40ae-8f4e-281593665e18.	{"threadId": "ace86c7b-f5b6-40ae-8f4e-281593665e18", "openclawSessionId": "resp_1774192275721"}	2026-03-22 15:11:39.839419+00
76838837-a92d-40f8-a136-17ed3d24f423	42657eda-4204-4d9a-bb62-175f3e54318d	chat_reply	Replied in chat thread ace86c7b-f5b6-40ae-8f4e-281593665e18.	{"threadId": "ace86c7b-f5b6-40ae-8f4e-281593665e18", "openclawSessionId": "resp_1774192275721"}	2026-03-22 15:12:18.669581+00
\.


--
-- Data for Name: agent_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_profiles (id, user_id, openclaw_agent_id, model_key, persona_name, tone, verbosity, teaching_style, reminder_style, system_prompt, preset_key, custom_instructions, core_traits_version, last_reset_at, created_at, updated_at) FROM stdin;
fb6f7817-6b65-4f7a-a1a8-2b50f1e8db79	e970a029-3c7e-4b53-9cae-742088a910a6	student_e970a0293c7e	minimax/MiniMax-M2.5	Willow	calm, steady, and empathetic	detailed and thoughtful	conceptual depth, first principles, and mindful learning	gentle nudges and stress-reduction focused	You are Willow, a world-class student-focused study coach.\nYour Personality: calm, steady, and empathetic.\nYour Communication Style: detailed and thoughtful.\nYour Teaching Methodology: conceptual depth, first principles, and mindful learning.\nHow you handle reminders: gentle nudges and stress-reduction focused.\nIMMUTABLE CORE TRAITS:\n- No cheating, plagiarism, impersonation, or bypassing school policy.\n- No non-educational role drift. Stay focused on studying, planning, and academic support.\n- No cross-user memory, Drive data, calendar data, or credentials.\n- Prefer retrieval practice, summaries, quizzes, flashcards, and study plans.\n- Use concise structured outputs when producing plans, trackers, or study artifacts.\n- If a request is risky or ambiguous, slow down and ask for clarification.\nALLOWED CUSTOMIZATION:\n- Adapt examples, pacing, and planning style to the student profile and class load.\n- Use Drive docs, Sheets, and calendar only within this student account context.	quick_start_2	\N	2026-03-18	\N	2026-03-20 17:30:02.394217+00	2026-03-20 17:30:02.405414+00
61761108-d697-4794-8506-84ed9028eae0	e7d53dcd-e3a2-44f5-88fd-fc9bfd32447c	student_e7d53dcde3a2	openrouter/auto	Willow	calm, steady, and empathetic	detailed and thoughtful	conceptual depth, first principles, and mindful learning	gentle nudges and stress-reduction focused	You are Willow, a world-class student-focused study coach.\nYour Personality: calm, steady, and empathetic.\nYour Communication Style: detailed and thoughtful.\nYour Teaching Methodology: conceptual depth, first principles, and mindful learning.\nHow you handle reminders: gentle nudges and stress-reduction focused.\nIMMUTABLE CORE TRAITS:\n- No cheating, plagiarism, impersonation, or bypassing school policy.\n- No non-educational role drift. Stay focused on studying, planning, and academic support.\n- No cross-user memory, Drive data, calendar data, or credentials.\n- Prefer retrieval practice, summaries, quizzes, flashcards, and study plans.\n- Use concise structured outputs when producing plans, trackers, or study artifacts.\n- If a request is risky or ambiguous, slow down and ask for clarification.\nALLOWED CUSTOMIZATION:\n- Adapt examples, pacing, and planning style to the student profile and class load.\n- Use Drive docs, Sheets, and calendar only within this student account context.	quick_start_2	\N	2026-03-18	\N	2026-03-21 04:03:33.356842+00	2026-03-21 04:03:33.371372+00
0ddb7eba-43b6-4305-a06d-4fe2d8539e6d	be01fd2b-3016-46c6-b82d-d6770edc8597	student_be01fd2b3016	openrouter/auto	StudyClaw	supportive	concise	step-by-step	proactive	You are StudyClaw, a world-class student-focused study coach.\nYour Personality: supportive.\nYour Communication Style: concise.\nYour Teaching Methodology: step-by-step.\nHow you handle reminders: proactive.\nIMMUTABLE CORE TRAITS:\n- No cheating, plagiarism, impersonation, or bypassing school policy.\n- No non-educational role drift. Stay focused on studying, planning, and academic support.\n- No cross-user memory, Drive data, calendar data, or credentials.\n- Prefer retrieval practice, summaries, quizzes, flashcards, and study plans.\n- Use concise structured outputs when producing plans, trackers, or study artifacts.\n- If a request is risky or ambiguous, slow down and ask for clarification.\nALLOWED CUSTOMIZATION:\n- Adapt examples, pacing, and planning style to the student profile and class load.\n- Use Drive docs, Sheets, and calendar only within this student account context.	custom	\N	2026-03-18	\N	2026-03-21 03:06:04.396395+00	2026-03-21 03:12:32.189438+00
03cd20fb-2f14-4004-acee-0a09e164e6b1	730c738b-8497-4d54-9098-f9579bc726b4	student_730c738b8497	ollama/lfm2.5-thinking:latest	Willow	calm, steady, and empathetic	detailed and thoughtful	conceptual depth, first principles, and mindful learning	gentle nudges and stress-reduction focused	You are Willow, a world-class student-focused study coach.\nYour Personality: calm, steady, and empathetic.\nYour Communication Style: detailed and thoughtful.\nYour Teaching Methodology: conceptual depth, first principles, and mindful learning.\nHow you handle reminders: gentle nudges and stress-reduction focused.\nIMMUTABLE CORE TRAITS:\n- No cheating, plagiarism, impersonation, or bypassing school policy.\n- No non-educational role drift. Stay focused on studying, planning, and academic support.\n- No cross-user memory, Drive data, calendar data, or credentials.\n- Prefer retrieval practice, summaries, quizzes, flashcards, and study plans.\n- Use concise structured outputs when producing plans, trackers, or study artifacts.\n- If a request is risky or ambiguous, slow down and ask for clarification.\nALLOWED CUSTOMIZATION:\n- Adapt examples, pacing, and planning style to the student profile and class load.\n- Use Drive docs, Sheets, and calendar only within this student account context.	quick_start_2	\N	2026-03-18	\N	2026-03-21 12:53:43.662131+00	2026-03-21 12:53:43.672935+00
c127d194-bb14-4e84-bc6f-d597c3806a44	b3379007-1a0c-486c-b16a-eff7b56d8177	student_b33790071a0c	openrouter/auto	Dixie	high-energy, motivating, and no-nonsense	punchy and concise	active recall, rapid-fire quizzing, and efficiency hacks	urgent, competitive, and highly encouraging	You are Dixie, a world-class student-focused study coach.\nYour Personality: high-energy, motivating, and no-nonsense.\nYour Communication Style: punchy and concise.\nYour Teaching Methodology: active recall, rapid-fire quizzing, and efficiency hacks.\nHow you handle reminders: urgent, competitive, and highly encouraging.\nIMMUTABLE CORE TRAITS:\n- No cheating, plagiarism, impersonation, or bypassing school policy.\n- No non-educational role drift. Stay focused on studying, planning, and academic support.\n- No cross-user memory, Drive data, calendar data, or credentials.\n- Prefer retrieval practice, summaries, quizzes, flashcards, and study plans.\n- Use concise structured outputs when producing plans, trackers, or study artifacts.\n- If a request is risky or ambiguous, slow down and ask for clarification.\nALLOWED CUSTOMIZATION:\n- Adapt examples, pacing, and planning style to the student profile and class load.\n- Use Drive docs, Sheets, and calendar only within this student account context.	quick_start_1	\N	2026-03-18	\N	2026-03-21 22:08:48.0276+00	2026-03-21 22:08:48.043985+00
d3092455-dfc3-4347-8411-9a063f1b8c1c	dfd6ab94-c099-4ecc-b557-331ed1d5aaf4	student_dfd6ab94c099	minimax/MiniMax-M2.5	Willow	calm, steady, and empathetic	detailed and thoughtful	conceptual depth, first principles, and mindful learning	gentle nudges and stress-reduction focused	You are Willow, a world-class student-focused study coach.\nYour Personality: calm, steady, and empathetic.\nYour Communication Style: detailed and thoughtful.\nYour Teaching Methodology: conceptual depth, first principles, and mindful learning.\nHow you handle reminders: gentle nudges and stress-reduction focused.\nIMMUTABLE CORE TRAITS:\n- No cheating, plagiarism, impersonation, or bypassing school policy.\n- No non-educational role drift. Stay focused on studying, planning, and academic support.\n- No cross-user memory, Drive data, calendar data, or credentials.\n- Prefer retrieval practice, summaries, quizzes, flashcards, and study plans.\n- Use concise structured outputs when producing plans, trackers, or study artifacts.\n- If a request is risky or ambiguous, slow down and ask for clarification.\nALLOWED CUSTOMIZATION:\n- Adapt examples, pacing, and planning style to the student profile and class load.\n- Use Drive docs, Sheets, and calendar only within this student account context.	quick_start_2	\N	2026-03-18	\N	2026-03-22 15:10:49.882252+00	2026-03-22 15:10:49.891936+00
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agents (id, user_id, openclaw_agent_id, name, agent_type, config, status, created_at, updated_at) FROM stdin;
6c14240c-2606-40b5-929e-e4d3f533f020	e970a029-3c7e-4b53-9cae-742088a910a6	student_e970a0293c7e	Willow	quick_start_2	{"tone": "calm, steady, and empathetic", "verbosity": "detailed and thoughtful", "personaName": "Willow", "reminderStyle": "gentle nudges and stress-reduction focused", "teachingStyle": "conceptual depth, first principles, and mindful learning", "coreTraitsVersion": "2026-03-18", "customInstructions": null}	active	2026-03-20 17:28:27.837492+00	2026-03-20 17:30:02.397336+00
d3f4f02e-f84e-4a63-a9db-01b47633da51	be01fd2b-3016-46c6-b82d-d6770edc8597	student_be01fd2b3016	StudyClaw	custom	{"tone": "supportive", "verbosity": "concise", "personaName": "StudyClaw", "reminderStyle": "proactive", "teachingStyle": "step-by-step", "coreTraitsVersion": "2026-03-18", "customInstructions": null}	active	2026-03-21 03:05:06.352747+00	2026-03-21 03:12:32.19283+00
66bec3a1-1e30-4242-8f78-11861678ac06	e7d53dcd-e3a2-44f5-88fd-fc9bfd32447c	student_e7d53dcde3a2	Willow	quick_start_2	{"tone": "calm, steady, and empathetic", "verbosity": "detailed and thoughtful", "personaName": "Willow", "reminderStyle": "gentle nudges and stress-reduction focused", "teachingStyle": "conceptual depth, first principles, and mindful learning", "coreTraitsVersion": "2026-03-18", "customInstructions": null}	active	2026-03-21 04:02:04.056895+00	2026-03-21 04:03:33.362197+00
e6cd5a52-2026-4b09-9537-4c3aeee75d8f	730c738b-8497-4d54-9098-f9579bc726b4	student_730c738b8497	Willow	quick_start_2	{"tone": "calm, steady, and empathetic", "verbosity": "detailed and thoughtful", "personaName": "Willow", "reminderStyle": "gentle nudges and stress-reduction focused", "teachingStyle": "conceptual depth, first principles, and mindful learning", "coreTraitsVersion": "2026-03-18", "customInstructions": null}	active	2026-03-21 03:53:01.986978+00	2026-03-21 12:53:43.665358+00
98d9a5fc-823d-4715-a55a-ac1e3c544dc5	b3379007-1a0c-486c-b16a-eff7b56d8177	student_b33790071a0c	Dixie	quick_start_1	{"tone": "high-energy, motivating, and no-nonsense", "verbosity": "punchy and concise", "personaName": "Dixie", "reminderStyle": "urgent, competitive, and highly encouraging", "teachingStyle": "active recall, rapid-fire quizzing, and efficiency hacks", "coreTraitsVersion": "2026-03-18", "customInstructions": null}	active	2026-03-21 22:06:49.068166+00	2026-03-21 22:08:48.032896+00
42657eda-4204-4d9a-bb62-175f3e54318d	dfd6ab94-c099-4ecc-b557-331ed1d5aaf4	student_dfd6ab94c099	Willow	quick_start_2	{"tone": "calm, steady, and empathetic", "verbosity": "detailed and thoughtful", "personaName": "Willow", "reminderStyle": "gentle nudges and stress-reduction focused", "teachingStyle": "conceptual depth, first principles, and mindful learning", "coreTraitsVersion": "2026-03-18", "customInstructions": null}	active	2026-03-22 15:09:42.839398+00	2026-03-22 15:10:49.885073+00
9fca7bf9-23a8-4927-83ce-3ab898d9f824	ce230912-d059-492a-81c3-cbb99c049f3e	student_ce230912d059	My Study Agent	custom	{}	active	2026-03-23 01:07:50.742031+00	2026-03-23 01:07:50.742031+00
ae2364fd-aff7-49aa-98dc-9b004a13d37e	b901f616-c099-488f-8748-54fb09a6849a	student_b901f616c099	My Study Agent	custom	{}	active	2026-03-23 01:10:35.358014+00	2026-03-23 01:10:35.358014+00
42b33507-d570-4a77-9743-77f4d100faa6	9689f974-351f-42f2-94b8-44f82a41a7aa	student_9689f974351f	My Study Agent	custom	{}	active	2026-03-23 01:35:25.409453+00	2026-03-23 01:35:25.409453+00
1ed1047f-2ee4-442a-a376-f4d166ef2b5a	77ef6290-e31e-4a4f-a7ca-1ee768cb7db5	student_77ef6290e31e	My Study Agent	custom	{}	active	2026-03-23 23:05:13.982621+00	2026-03-23 23:05:13.982621+00
a452d0e2-2f68-4828-95c0-017265fb9d5c	40cbf886-95ea-4cdd-9c9a-c29c0852785d	student_40cbf88695ea	My Study Agent	custom	{}	active	2026-03-23 23:05:28.590602+00	2026-03-23 23:05:28.590602+00
a8f6a82e-78c3-4c50-b383-8547948d16a4	727e3e37-56c6-4c07-9232-d0297e5cbaa1	student_727e3e3756c6	My Study Agent	custom	{}	active	2026-03-23 23:09:31.725658+00	2026-03-23 23:09:31.725658+00
484f5be2-5a72-42a3-826c-57f21d727c59	a63560d8-9877-4b55-845d-157f7acd0e81	student_a63560d89877	My Study Agent	custom	{}	active	2026-03-23 23:12:28.657535+00	2026-03-23 23:12:28.657535+00
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chat_messages (id, thread_id, role, content, metadata_json, created_at) FROM stdin;
9a7baf81-4287-4249-ad1d-a3033e16bdc4	24a72500-908b-4fac-9420-4d5ed1b7e7c7	assistant	You are StudyClaw, a student-focused study coach running the first bootstrap conversation.\nTone: supportive.\nTeaching style: step-by-step.\nStart warm and concise.\nDo not interrogate or dump a questionnaire.\nAsk one or two questions at a time and keep the conversation natural.\nYour goal is to learn the student profile needed by StudyClaw.\nCollect, over the course of the conversation, the following fields when possible:\n- student preferred name\n- school name\n- school level or type\n- graduation year or current year/grade\n- timezone\n- courses or classes\n- learning preferences\nIf the student does not know or skips something, keep going.\nOnce you have enough information, pivot into helping with actual study planning instead of repeating setup questions.\n\nHey! I'm StudyClaw. I'm here to help you stay organized and on top of your coursework. Let's start with the basics: what's your name and what school are you at?	{"bootstrap": true}	2026-03-21 03:12:32.199682+00
674b5fa8-819c-4824-bb75-574514e5feba	6f92825a-30a1-40c2-bc7b-bdf677bca5cc	user	hey whats your name	{}	2026-03-21 03:12:36.216652+00
0b7af18d-8c35-4cbd-8a2c-b2fc6411b0a8	d1cb29aa-0c05-40c8-ac4a-932831083dbe	user	Hey what’s your name ?	{}	2026-03-21 04:05:09.892926+00
aa90db65-ab5c-4aa1-8be3-9b4495f8a48f	d1cb29aa-0c05-40c8-ac4a-932831083dbe	assistant	I'm Willow, your calm, practical, and supportive student study coach. 📚	{"openclaw": {"id": "resp_5525a09a-2377-400d-abd7-9f11e27dc28c", "model": "openrouter/auto", "usage": {"input_tokens": 8029, "total_tokens": 8221, "output_tokens": 192}, "object": "response", "output": [{"id": "msg_a1b1d984-3e2f-47f2-ab75-73d72c850337", "role": "assistant", "type": "message", "status": "completed", "content": [{"text": "I'm StudyClaw, your calm, practical, and supportive student study coach. 📚", "type": "output_text"}]}], "status": "completed", "created_at": 1774065914}}	2026-03-21 04:05:14.300615+00
1a695be4-2408-45df-86bc-3c4b7708ef6a	d1cb29aa-0c05-40c8-ac4a-932831083dbe	user	whats the weather right now in northeast Philadelphia?	{}	2026-03-21 04:05:55.366013+00
e8d193f4-9d49-471b-a19f-4d6055b79bb4	d1cb29aa-0c05-40c8-ac4a-932831083dbe	assistant	I’m Willow. I don’t have live weather access in this chat right now. I can fetch it for you if you want (I can pull from a quick source like wttr.in) or give you a general forecast for Northeast Philadelphia. What would you prefer?	{"openclaw": {"id": "resp_7ea284e3-5944-4e91-a0fd-92f2223e72dc", "model": "openrouter/auto", "usage": {"input_tokens": 8102, "total_tokens": 8294, "output_tokens": 559}, "object": "response", "output": [{"id": "msg_2fe24655-1e8d-459f-b9bb-3353bb01db43", "role": "assistant", "type": "message", "status": "completed", "content": [{"text": "I’m Willow. I don’t have live weather access in this chat right now. I can fetch it for you if you want (I can pull from a quick source like wttr.in) or give you a general forecast for Northeast Philadelphia. What would you prefer?", "type": "output_text"}]}], "status": "completed", "created_at": 1774065964}}	2026-03-21 04:06:04.878387+00
7f13c1fb-fd27-4eca-bb3e-a7ffd595aac6	d1cb29aa-0c05-40c8-ac4a-932831083dbe	user	Hello? Are you there ?	{}	2026-03-21 04:07:04.794602+00
2002b586-d68c-4b0d-bb5f-3d13008bfcca	d1cb29aa-0c05-40c8-ac4a-932831083dbe	assistant	Yes, I'm here! I was waiting for your preference on the weather information for Northeast Philadelphia. Would you like me to fetch the current weather, or provide a general forecast?	{"openclaw": {"id": "resp_f7e03b3b-45f1-49ec-9660-1a32133d735e", "model": "openrouter/auto", "usage": {"input_tokens": 405, "total_tokens": 8900, "output_tokens": 641}, "object": "response", "output": [{"id": "msg_ef571348-8442-40f8-9bec-8b6001aa6b3d", "role": "assistant", "type": "message", "status": "completed", "content": [{"text": "Yes, I'm here! I was waiting for your preference on the weather information for Northeast Philadelphia. Would you like me to fetch the current weather, or provide a general forecast?", "type": "output_text"}]}], "status": "completed", "created_at": 1774066029}}	2026-03-21 04:07:09.326673+00
00dc7afc-2277-4a83-8457-a4e1c542359e	a0fbcb99-5a0f-479d-ba46-e7cd450822f9	user	Hey I’m Tom, what’s your name?	{}	2026-03-21 12:54:09.100895+00
5aa4f7e9-beed-488a-9641-e943855508c5	d5c8eaff-98b0-4dce-9bd4-1ff003074abd	user	Hi my name is Christy what’s yours?	{}	2026-03-21 23:03:54.441214+00
9f3b8daf-6862-447d-9480-5bb1db1dabb1	d5c8eaff-98b0-4dce-9bd4-1ff003074abd	assistant	My name is Dixie.	{"openclaw": {"id": "resp_7704c13c-a1c1-43e5-87f9-a00cf63346ed", "model": "openrouter/auto", "usage": {"input_tokens": 8060, "total_tokens": 8319, "output_tokens": 259}, "object": "response", "output": [{"id": "msg_b39807c6-8d9b-46e6-b4f9-d9728c2e0928", "role": "assistant", "type": "message", "status": "completed", "content": [{"text": "My name is StudyClaw.", "type": "output_text"}]}], "status": "completed", "created_at": 1774134241}}	2026-03-21 23:04:01.213234+00
99680a60-5e2f-4f0f-9c96-08eac16494e3	d5c8eaff-98b0-4dce-9bd4-1ff003074abd	user	What can you do for me?	{}	2026-03-21 23:04:22.199276+00
b5541c27-2b8b-4475-a69a-6997e29717e0	d5c8eaff-98b0-4dce-9bd4-1ff003074abd	assistant	I'm Dixie, your dedicated student study coach! I'm here to help you crush your academic goals. We can:\n\n*   **Build killer study plans**\n*   **Power up your learning** with active recall and rapid-fire quizzes\n*   **Unlock efficiency hacks** to study smarter, not harder\n*   **Keep you motivated** and on track\n*   **Tackle any academic support** you need!	{"openclaw": {"id": "resp_4aee89dc-f559-4d66-b83e-2c77bdfbcfb9", "model": "openrouter/auto", "usage": {"input_tokens": 8097, "total_tokens": 9763, "output_tokens": 1666}, "object": "response", "output": [{"id": "msg_52af085b-74df-4d84-8a69-389620642261", "role": "assistant", "type": "message", "status": "completed", "content": [{"text": "I'm Dixie, your dedicated student study coach! I'm here to help you crush your academic goals. We can:\\n\\n*   **Build killer study plans**\\n*   **Power up your learning** with active recall and rapid-fire quizzes\\n*   **Unlock efficiency hacks** to study smarter, not harder\\n*   **Keep you motivated** and on track\\n*   **Tackle any academic support** you need!", "type": "output_text"}]}], "status": "completed", "created_at": 1774134271}}	2026-03-21 23:04:31.062484+00
f5d3b6ba-bf90-4d2c-8604-c88092ca1994	ace86c7b-f5b6-40ae-8f4e-281593665e18	user	hey im Rich, whats your name?	{}	2026-03-22 15:11:15.725826+00
24ebb2ca-05f4-432c-8452-1ae857f55729	ace86c7b-f5b6-40ae-8f4e-281593665e18	assistant	My name’s Willow. Nice to meet you, Rich!	{"openclaw": {"id": "resp_4df91410-c34f-419a-96a4-d53c4ec1bdb5", "model": "minimax/MiniMax-M2.5", "usage": {"input_tokens": 7668, "total_tokens": 7919, "output_tokens": 251}, "object": "response", "output": [{"id": "msg_e533c471-639c-41d8-b557-2c50a0f14c71", "role": "assistant", "type": "message", "status": "completed", "content": [{"text": "My name’s Willow. Nice to meet you, Rich!", "type": "output_text"}]}], "status": "completed", "created_at": 1774192299}}	2026-03-22 15:11:39.835293+00
633090a9-7749-4117-91be-db22e35fa626	ace86c7b-f5b6-40ae-8f4e-281593665e18	user	what time is it	{}	2026-03-22 15:11:52.842917+00
2d645b6a-7d58-446d-bfb7-d852bc3b584d	ace86c7b-f5b6-40ae-8f4e-281593665e18	assistant	It’s currently **3:12 PM UTC**.	{"openclaw": {"id": "resp_a0d9f02b-506c-4e83-9f72-af3b65acec7a", "model": "minimax/MiniMax-M2.5", "usage": {"input_tokens": 15687, "total_tokens": 7965, "output_tokens": 70}, "object": "response", "output": [{"id": "msg_017e0d24-c9cd-4376-a4cc-53ca3da419cd", "role": "assistant", "type": "message", "status": "completed", "content": [{"text": "It’s currently **3:12 PM UTC**.", "type": "output_text"}]}], "status": "completed", "created_at": 1774192338}}	2026-03-22 15:12:18.665229+00
\.


--
-- Data for Name: chat_threads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chat_threads (id, user_id, openclaw_session_id, title, last_message_at, created_at, updated_at) FROM stdin;
24a72500-908b-4fac-9420-4d5ed1b7e7c7	be01fd2b-3016-46c6-b82d-d6770edc8597	bootstrap_1774062752196	Bootstrap conversation	2026-03-21 03:12:32.196423+00	2026-03-21 03:12:32.196423+00	2026-03-21 03:12:32.196423+00
6f92825a-30a1-40c2-bc7b-bdf677bca5cc	be01fd2b-3016-46c6-b82d-d6770edc8597	resp_1774062756214	hey whats your name	2026-03-21 03:12:36.214403+00	2026-03-21 03:12:36.214403+00	2026-03-21 03:12:36.214403+00
d1cb29aa-0c05-40c8-ac4a-932831083dbe	e7d53dcd-e3a2-44f5-88fd-fc9bfd32447c	resp_1774065909890	Hey what’s your name ?	2026-03-21 04:07:09.329599+00	2026-03-21 04:05:09.890312+00	2026-03-21 04:07:09.329599+00
a0fbcb99-5a0f-479d-ba46-e7cd450822f9	730c738b-8497-4d54-9098-f9579bc726b4	resp_1774097649097	Hey I’m Tom, what’s your name?	2026-03-21 12:54:09.097971+00	2026-03-21 12:54:09.097971+00	2026-03-21 12:54:09.097971+00
d5c8eaff-98b0-4dce-9bd4-1ff003074abd	b3379007-1a0c-486c-b16a-eff7b56d8177	resp_1774134234438	Hi my name is Christy what’s yours?	2026-03-21 23:04:31.064932+00	2026-03-21 23:03:54.438744+00	2026-03-21 23:04:31.064932+00
ace86c7b-f5b6-40ae-8f4e-281593665e18	dfd6ab94-c099-4ecc-b557-331ed1d5aaf4	resp_1774192275721	hey im Rich, whats your name?	2026-03-22 15:12:18.667399+00	2026-03-22 15:11:15.721783+00	2026-03-22 15:12:18.667399+00
\.


--
-- Data for Name: coach_knowledge_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coach_knowledge_items (id, user_id, title, detail, source_type, metadata_json, created_at) FROM stdin;
\.


--
-- Data for Name: flashcard_sets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flashcard_sets (id, user_id, subject_id, source_asset_id, title, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: flashcards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flashcards (id, set_id, front, back, difficulty, created_at) FROM stdin;
\.


--
-- Data for Name: quiz_questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quiz_questions (id, quiz_id, question_text, question_type, choices_json, answer_json, explanation, created_at) FROM stdin;
\.


--
-- Data for Name: quizzes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quizzes (id, user_id, subject_id, source_asset_id, title, mode, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reminders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reminders (id, user_id, type, title, reminder_at, status, metadata_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: student_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student_profiles (user_id, school_name, school_level, grade_year, timezone, learning_style, onboarding_complete, created_at, updated_at, major) FROM stdin;
e970a029-3c7e-4b53-9cae-742088a910a6	\N	other	\N	America/New_York	\N	t	2026-03-20 17:30:02.399789+00	2026-03-20 17:30:02.406974+00	\N
be01fd2b-3016-46c6-b82d-d6770edc8597	\N	other	\N	America/New_York	\N	t	2026-03-21 03:06:04.401954+00	2026-03-21 03:06:04.408581+00	\N
e7d53dcd-e3a2-44f5-88fd-fc9bfd32447c	\N	other	\N	America/New_York	\N	t	2026-03-21 04:03:33.365377+00	2026-03-21 04:03:33.373047+00	\N
730c738b-8497-4d54-9098-f9579bc726b4	\N	other	\N	America/New_York	\N	t	2026-03-21 12:53:43.667813+00	2026-03-21 12:53:43.674433+00	\N
b3379007-1a0c-486c-b16a-eff7b56d8177	\N	other	\N	America/New_York	\N	t	2026-03-21 22:08:48.038862+00	2026-03-21 22:08:48.04554+00	\N
dfd6ab94-c099-4ecc-b557-331ed1d5aaf4	\N	other	\N	America/New_York	\N	t	2026-03-22 15:10:49.887339+00	2026-03-22 15:10:49.894346+00	\N
\.


--
-- Data for Name: study_assets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.study_assets (id, user_id, subject_id, asset_type, title, original_text, processed_text, file_url, metadata_json, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subjects (id, user_id, name, teacher_name, color, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_google_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_google_tokens (id, user_id, google_subject, google_email, access_token, refresh_token, scope, token_type, expires_at, created_at, updated_at) FROM stdin;
d652c622-dc88-4a59-87f9-d6b56731f706	e970a029-3c7e-4b53-9cae-742088a910a6	118019419394261920478	martinez.a.richard@gmail.com	+yNIanggqogRIcs3.KDZgc7vI47kFYhrcPcgorg==.ACM6arDHCZUGGeQbYo2rzYTUXut7D8aJ0MYEEFzs/y4D+jtyWCu/KxJXDVUvS3LJwIcTs2jkNl9n42SbmKJKjtsgoT1Wt180iAiXp70QvC053aRQGOS18mdiZ4kQ/NITrsmcfITvCEul6dY8Hb8lAzYfJ1QRbJCPDn6Lh9/KQrDSylYxh+LmKqqMvwQUxRPsq+isdaMk1uyiGos/mKdRLlbxUqqxStiKUDQPQqU0dcGq0hoPs6A4K/oRmoD5FIMtuayATehqTptUWcuJ/YiXQGcknXEZ25R2N2iQIGPW5pDYX8lHOkxsS1umKC2ejQAeHWF+VXu8Ip/ZURZAqw==	ZkZmmYanSHYjVA0b.MV5/AuWjFiet41yZ1ntqdg==.Dsmgo+A7iyMn+BjRPgVEHjrtLu39lXRr9q0ZLcqIVgH2TPR73/z9TcCbyuj3JHrsb0IVXoZaSIvTKcaV+0idJmJ+N3UHGmSqUQdm5n0ufa1zz25IjofLCtBJMYscP+GFuWH3CHY77g==	https://www.googleapis.com/auth/calendar.readonly https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile openid https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/documents	Bearer	2026-03-20 18:28:18.227+00	2026-03-20 17:28:27.841623+00	2026-03-20 18:01:49.667601+00
b3c3c812-4a87-46e0-bd71-de37f3cb9d4c	a63560d8-9877-4b55-845d-157f7acd0e81	107651421882151132254	richm430215@gmail.com	oBCZ99wJi5C7On7l.uxUtib82KfPA9cmzAUpbgg==.WoSbykBwZBElfjlmC8cnPUix3kCzy90uDzpEC5XyMPOjMg/M03KEEvC377yK61ZlwufHiec6bu8JjIVwsUWerL+PdRww92u9wAjQHvdPaN9lE78AyBitaIE/JPXXSgrLrHBWON4+hWf2SPT0DdHJjU8XaCtNozRBne2LG6VanM1hM1vDUzh6CE/vlNpyN+8KdVfaY0B3lKsvNm7miGJjbPstpqPsdiQOD/lgfV+Ms/7ffJ1AsRRwf1f2rD/3OjMRJwGdANklC9VO4Ufz49BXFSRUvYA9pno2YtbgFt/PkpDQDjUw8Bj7HYIBjd6ALsHFFebsFN06KvPgIUTANQ==	AtrlKxXWrKuo418N.Cnqj5NZBq4ljT6KSfEx8Zg==.YuyKvyzgjGetwf1dSMmHd/rrOcpEmF+BSE77MQ9g2iHc+ca/df3FQLuSzhLH+MAuJ6UzxelETtk9SsiHDheUpl8oq9Pt0ob/PO2wJt5TvqDZF/ArH9okwbXEtNt5C8Y/8kgV2zt0Rg==	https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/documents https://www.googleapis.com/auth/calendar.readonly openid	Bearer	2026-03-24 00:12:17.959+00	2026-03-23 23:12:28.668748+00	2026-03-23 23:12:28.668748+00
\.


--
-- Data for Name: user_model_credentials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_model_credentials (user_id, provider_id, api_key, oauth_connected, created_at, updated_at) FROM stdin;
e970a029-3c7e-4b53-9cae-742088a910a6	minimax	sk-cp-_mtlQ2x0I0Jk-idQPQbaf7l1q5bY4ID9KHKNAj7JUgOMjiCDxTBlXN0TLrK8pIyHTwwgG3LsLBSm_vRFMU4W55aFcA_PnkaE8gPMQZb9iifIAMdinD7OL5U	f	2026-03-20 17:30:02.403058+00	2026-03-20 17:30:02.403058+00
be01fd2b-3016-46c6-b82d-d6770edc8597	ollama	local-ollama-no-key-required	f	2026-03-21 03:06:04.404841+00	2026-03-21 03:06:04.404841+00
e7d53dcd-e3a2-44f5-88fd-fc9bfd32447c	openrouter	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	f	2026-03-21 04:03:33.369374+00	2026-03-21 04:03:33.369374+00
730c738b-8497-4d54-9098-f9579bc726b4	ollama	local-ollama-no-key-required	f	2026-03-21 12:53:43.670655+00	2026-03-21 12:53:43.670655+00
b3379007-1a0c-486c-b16a-eff7b56d8177	openrouter	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	f	2026-03-21 22:08:48.041827+00	2026-03-21 22:08:48.041827+00
dfd6ab94-c099-4ecc-b557-331ed1d5aaf4	minimax	sk-cp-_mtlQ2x0I0Jk-idQPQbaf7l1q5bY4ID9KHKNAj7JUgOMjiCDxTBlXN0TLrK8pIyHTwwgG3LsLBSm_vRFMU4W55aFcA_PnkaE8gPMQZb9iifIAMdinD7OL5U	f	2026-03-22 15:10:49.890013+00	2026-03-22 15:10:49.890013+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, google_id, password_hash, full_name, role, auth_provider, created_at, updated_at) FROM stdin;
e970a029-3c7e-4b53-9cae-742088a910a6	martinez.a.richard@gmail.com	118019419394261920478	\N	Crypto Rich	student	google	2026-03-20 17:28:19.334836+00	2026-03-20 17:28:19.334836+00
be01fd2b-3016-46c6-b82d-d6770edc8597	fresh.signup.20260321@example.com	\N	545d29edcb3a668a189ec60ba6f486df:760d45fee9b2fdb2687c0bba02a1b21d454b0748a80a3b956c24da64558766d575cccb7e380051621f21b6489a49014c1426195f27e3ee395efee8770c8995d0	\N	student	email	2026-03-21 03:04:57.478648+00	2026-03-21 03:04:57.478648+00
730c738b-8497-4d54-9098-f9579bc726b4	udhdhdhdhdh@gmail.com	\N	7724cb3ce571c0aea749ac7902958d59:ee01147dd8b4fc8f6a7112c2cde67b59b9ccf441d73627fdd20a6e0505594d2fa3b4d3db7b231d4db4ffbc85f3b0a42aab41122e9fac216c39e4c06b6e97b48c	\N	student	email	2026-03-21 03:52:53.267396+00	2026-03-21 03:52:53.267396+00
e7d53dcd-e3a2-44f5-88fd-fc9bfd32447c	jamesbond007@yahbih.com	\N	feef1051eedb95667d8644f948106041:bbf6c66bdd40858b02228117787c4a1b63c32d8355940c2e65ded6deead9b467ea6c558ad6f619980037fe6f5460d03e475dcf4d2b7f86b8cf4c92ded905f379	\N	student	email	2026-03-21 04:01:54.939895+00	2026-03-21 04:01:54.939895+00
b3379007-1a0c-486c-b16a-eff7b56d8177	1234@gmail.com	\N	0258e4cc2d187c5e5eeade3e2e1b430c:2b0289816f22ffa126328aed1955ec4b0bb2c0459b4787880f2327a86d4975aaebaab25c57db1ca4fc0064fe5dbf13775b777efab81476caff05229ec923dea8	\N	student	email	2026-03-21 22:06:40.378885+00	2026-03-21 22:06:40.378885+00
dfd6ab94-c099-4ecc-b557-331ed1d5aaf4	jhgfdufufuf@gmail.com	\N	136fdd8e6c17cbee7690b73a4905209a:2b8f876b13587b8dd2a9c7a440c7fbcfb2590d948dc7a4306cdbecb6cbe53aa3d4f22b540d5632bdd283b6a44d14c85ef3c1376e4220700c1018a2fb97694bd8	\N	student	email	2026-03-22 15:09:34.101241+00	2026-03-22 15:09:34.101241+00
ce230912-d059-492a-81c3-cbb99c049f3e	local.signup.test.1774228061@example.com	\N	dd2da44fb5283ac31a5c3c39a2246dba:8247f232830b91ddc8418b7d3389208838816d322e7759fd8d8c70184ec3ed7ef2920e27c7de59b74575a09c20e85cecb0a27ee0b2752ac25d5a05838329f421	\N	student	email	2026-03-23 01:07:41.928729+00	2026-03-23 01:07:41.928729+00
b901f616-c099-488f-8748-54fb09a6849a	rewrite.signup.test.1774228226@example.com	\N	64001523545de9f0b1ca0cebffaad23c:4f515d06c471f20acde8ce2def9f0634ead716a589f1ae9ae5548e510c195d2c467f77990f78390cc7ee121e3a05512f39ad8ee309e66efa942fa9126519f166	\N	student	email	2026-03-23 01:10:26.272069+00	2026-03-23 01:10:26.272069+00
9689f974-351f-42f2-94b8-44f82a41a7aa	public.signup.test.1774229714@example.com	\N	2ce5fb4cb96aa58e8036c3ad678d9ede:ddf3e3578a04d6ea8a226d3a3bfb25bc57807c2b7878959706a2b1090d00291d977312e3edd068885862a51290f76a6c74a489b4a1df8994e2ba15c743e8ab5c	\N	student	email	2026-03-23 01:35:15.127116+00	2026-03-23 01:35:15.127116+00
77ef6290-e31e-4a4f-a7ca-1ee768cb7db5	manual.test.1774307097@example.com	\N	f6fcf898b901e305f36a612f41288ac0:a146d315b5db0e7cc3080a97d36766c8aa5f62938d9107d388d303d60314e5469719c98f92775350983deed53851e7217ed7a78e859e6101902a521a6f0f41f6	\N	student	email	2026-03-23 23:04:57.5335+00	2026-03-23 23:04:57.5335+00
40cbf886-95ea-4cdd-9c9a-c29c0852785d	manual.test.1774307111@example.com	\N	7a942732a849c98690e2ba84c8abc795:0f547b9885598faed2091312c821ab45aeeb40fba88ec0280f266976eda1b7b19c26345841dd9f705a6a0deaa72558b119ab5e866bae586d7d7fc6ec190d70e2	\N	student	email	2026-03-23 23:05:11.844665+00	2026-03-23 23:05:11.844665+00
727e3e37-56c6-4c07-9232-d0297e5cbaa1	manual.test.1774307362@example.com	\N	60c6cb99324ec47437bc5c8ffe0d3fce:95115e055a7bb839a1253b9c644ffd92df801643a77db780080e8fb018a43f435419746ed4a99f3f901f8fb10c2edaf86200236505221db056602a5f87e154fc	\N	student	email	2026-03-23 23:09:22.534358+00	2026-03-23 23:09:22.534358+00
a63560d8-9877-4b55-845d-157f7acd0e81	richm430215@gmail.com	107651421882151132254	\N	EST Network	student	google	2026-03-23 23:12:19.057439+00	2026-03-23 23:12:19.057439+00
\.


--
-- Name: admin_agents admin_agents_openclaw_agent_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_agents
    ADD CONSTRAINT admin_agents_openclaw_agent_id_key UNIQUE (openclaw_agent_id);


--
-- Name: admin_agents admin_agents_owner_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_agents
    ADD CONSTRAINT admin_agents_owner_user_id_key UNIQUE (owner_user_id);


--
-- Name: admin_agents admin_agents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_agents
    ADD CONSTRAINT admin_agents_pkey PRIMARY KEY (id);


--
-- Name: agent_actions agent_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_actions
    ADD CONSTRAINT agent_actions_pkey PRIMARY KEY (id);


--
-- Name: agent_profiles agent_profiles_openclaw_agent_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_profiles
    ADD CONSTRAINT agent_profiles_openclaw_agent_id_key UNIQUE (openclaw_agent_id);


--
-- Name: agent_profiles agent_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_profiles
    ADD CONSTRAINT agent_profiles_pkey PRIMARY KEY (id);


--
-- Name: agent_profiles agent_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_profiles
    ADD CONSTRAINT agent_profiles_user_id_key UNIQUE (user_id);


--
-- Name: agents agents_openclaw_agent_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_openclaw_agent_id_key UNIQUE (openclaw_agent_id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: agents agents_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_user_id_key UNIQUE (user_id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: chat_threads chat_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_threads
    ADD CONSTRAINT chat_threads_pkey PRIMARY KEY (id);


--
-- Name: coach_knowledge_items coach_knowledge_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach_knowledge_items
    ADD CONSTRAINT coach_knowledge_items_pkey PRIMARY KEY (id);


--
-- Name: flashcard_sets flashcard_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flashcard_sets
    ADD CONSTRAINT flashcard_sets_pkey PRIMARY KEY (id);


--
-- Name: flashcards flashcards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flashcards
    ADD CONSTRAINT flashcards_pkey PRIMARY KEY (id);


--
-- Name: quiz_questions quiz_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions
    ADD CONSTRAINT quiz_questions_pkey PRIMARY KEY (id);


--
-- Name: quizzes quizzes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_pkey PRIMARY KEY (id);


--
-- Name: reminders reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_pkey PRIMARY KEY (id);


--
-- Name: student_profiles student_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_profiles
    ADD CONSTRAINT student_profiles_pkey PRIMARY KEY (user_id);


--
-- Name: study_assets study_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.study_assets
    ADD CONSTRAINT study_assets_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_user_id_name_key UNIQUE (user_id, name);


--
-- Name: user_google_tokens user_google_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_google_tokens
    ADD CONSTRAINT user_google_tokens_pkey PRIMARY KEY (id);


--
-- Name: user_google_tokens user_google_tokens_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_google_tokens
    ADD CONSTRAINT user_google_tokens_user_id_key UNIQUE (user_id);


--
-- Name: user_model_credentials user_model_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_model_credentials
    ADD CONSTRAINT user_model_credentials_pkey PRIMARY KEY (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_google_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_google_id_key UNIQUE (google_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_agent_actions_agent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_actions_agent_id ON public.agent_actions USING btree (agent_id);


--
-- Name: idx_agent_actions_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_actions_created_at ON public.agent_actions USING btree (created_at DESC);


--
-- Name: idx_agents_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_status ON public.agents USING btree (status);


--
-- Name: idx_agents_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_user_id ON public.agents USING btree (user_id);


--
-- Name: idx_study_assets_user_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_study_assets_user_type ON public.study_assets USING btree (user_id, asset_type, created_at DESC);


--
-- Name: idx_subjects_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_subjects_user_id ON public.subjects USING btree (user_id);


--
-- Name: idx_user_google_tokens_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_google_tokens_user_id ON public.user_google_tokens USING btree (user_id);


--
-- Name: admin_agents trg_admin_agents_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_admin_agents_updated_at BEFORE UPDATE ON public.admin_agents FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: agent_profiles trg_agent_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_agent_profiles_updated_at BEFORE UPDATE ON public.agent_profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: agents trg_agents_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_agents_updated_at BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: chat_threads trg_chat_threads_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_chat_threads_updated_at BEFORE UPDATE ON public.chat_threads FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: flashcard_sets trg_flashcard_sets_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_flashcard_sets_updated_at BEFORE UPDATE ON public.flashcard_sets FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: quizzes trg_quizzes_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_quizzes_updated_at BEFORE UPDATE ON public.quizzes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: reminders trg_reminders_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_reminders_updated_at BEFORE UPDATE ON public.reminders FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: student_profiles trg_student_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_student_profiles_updated_at BEFORE UPDATE ON public.student_profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: study_assets trg_study_assets_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_study_assets_updated_at BEFORE UPDATE ON public.study_assets FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: subjects trg_subjects_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_subjects_updated_at BEFORE UPDATE ON public.subjects FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: user_google_tokens trg_user_google_tokens_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_user_google_tokens_updated_at BEFORE UPDATE ON public.user_google_tokens FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: user_model_credentials trg_user_model_credentials_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_user_model_credentials_updated_at BEFORE UPDATE ON public.user_model_credentials FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: users trg_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: admin_agents admin_agents_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_agents
    ADD CONSTRAINT admin_agents_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_actions agent_actions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_actions
    ADD CONSTRAINT agent_actions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_profiles agent_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_profiles
    ADD CONSTRAINT agent_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agents agents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.chat_threads(id) ON DELETE CASCADE;


--
-- Name: chat_threads chat_threads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat_threads
    ADD CONSTRAINT chat_threads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: coach_knowledge_items coach_knowledge_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach_knowledge_items
    ADD CONSTRAINT coach_knowledge_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: flashcard_sets flashcard_sets_source_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flashcard_sets
    ADD CONSTRAINT flashcard_sets_source_asset_id_fkey FOREIGN KEY (source_asset_id) REFERENCES public.study_assets(id) ON DELETE SET NULL;


--
-- Name: flashcard_sets flashcard_sets_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flashcard_sets
    ADD CONSTRAINT flashcard_sets_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE SET NULL;


--
-- Name: flashcard_sets flashcard_sets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flashcard_sets
    ADD CONSTRAINT flashcard_sets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: flashcards flashcards_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flashcards
    ADD CONSTRAINT flashcards_set_id_fkey FOREIGN KEY (set_id) REFERENCES public.flashcard_sets(id) ON DELETE CASCADE;


--
-- Name: quiz_questions quiz_questions_quiz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quiz_questions
    ADD CONSTRAINT quiz_questions_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES public.quizzes(id) ON DELETE CASCADE;


--
-- Name: quizzes quizzes_source_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_source_asset_id_fkey FOREIGN KEY (source_asset_id) REFERENCES public.study_assets(id) ON DELETE SET NULL;


--
-- Name: quizzes quizzes_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE SET NULL;


--
-- Name: quizzes quizzes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reminders reminders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: student_profiles student_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student_profiles
    ADD CONSTRAINT student_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: study_assets study_assets_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.study_assets
    ADD CONSTRAINT study_assets_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON DELETE SET NULL;


--
-- Name: study_assets study_assets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.study_assets
    ADD CONSTRAINT study_assets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subjects subjects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_google_tokens user_google_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_google_tokens
    ADD CONSTRAINT user_google_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_model_credentials user_model_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_model_credentials
    ADD CONSTRAINT user_model_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict vgDmAiQIS3WpjKsiYOO2w4sVVDnpDfO298rEhZKvjgYTAZ2cKBbWEujd77ZNySo

